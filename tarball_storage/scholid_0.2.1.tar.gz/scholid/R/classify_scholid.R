#' Classify scholarly identifiers
#'
#' @description
#' Performs best-guess classification of scholarly identifier strings.
#' For each element of the input, the function returns the first matching
#' identifier type, or `NA_character_` if no supported type matches.
#'
#' Classification is based on canonical identifier syntax. Types are checked
#' in the order returned by [scholid_types()] (most specific first); the first
#' match wins. Wrapped forms (e.g., URLs or labels) should be normalized first
#' with `normalize_scholid()`.
#'
#' @param x A vector of candidate identifier values.
#'
#' @return A character vector of the same length as `x`, giving the detected
#'   identifier type for each element, or `NA_character_` if no match is
#'   found.
#'
#' @examples
#' classify_scholid(c("10.1000/182", "0000-0002-1825-0097", "not an id"))
#' classify_scholid(normalize_scholid("https://doi.org/10.1000/182", "doi"))
#'
#' @seealso [detect_scholid_type()], [scholid_types()],
#'   [scholid_definitions](../doc/scholid_definitions.html)
#' @export
classify_scholid <- function(x) {
    .scholid_check_x(
        x,
        arg = "x"
        )

    x <- as.character(x)
    out <- rep(
        NA_character_,
        length(x)
        )

    idx <- which(!is.na(x))
    if (!length(idx)) {
        return(out)
    }

    types <- scholid_types()

    for (type in types) {
        fun <- .scholid_resolve_impl(
            type     = type,
            prefix   = "is_",
            required = FALSE
        )

        if (is.null(fun)) {
            next
        }

        res <- fun(x[idx])
        hit <- !is.na(res) & res
        out[idx[hit]] <- type
        idx <- idx[!hit]

        if (!length(idx)) {
            break
        }
    }

    out
}
